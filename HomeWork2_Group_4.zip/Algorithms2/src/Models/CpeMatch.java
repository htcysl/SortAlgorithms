/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

public class CpeMatch {
    public boolean vulnerable;
    public String criteria;
    public String matchCriteriaId;
    public String versionEndIncluding;
   
}
