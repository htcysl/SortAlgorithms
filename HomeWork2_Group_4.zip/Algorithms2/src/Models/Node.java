/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

import java.util.ArrayList;

/**
 *
 * @author HP
 */
public class Node {
    public String operator;
    public boolean negate;
    public ArrayList<CpeMatch> cpeMatch;
}
